import cv2
import numpy as np
import tkinter

from tkinter import *
from PIL import ImageTk, Image

color = [0,0,0]

thresh = 175
min = 100
Anzahl = 0
max = 100000
def button_action():
    if not(SchwarzWeiss.get() == ""):
        global thresh
        thresh = int(SchwarzWeiss.get())
        SchwarzweissText = Label(fenster, text="SchwarzWeissfilter: " + str(thresh))
        SchwarzweissText.place(x=0, y=0, width=200, height=30)
    if not(mindestgroesse.get() == ""):
        global min
        min = int(mindestgroesse.get())
        mindestgroesseText = Label(fenster, text="Mindestgroesse: " + str(min))
        mindestgroesseText.place(x=0, y=30, width=200, height=30)
    if not (maximalgroesse.get() == ""):
        global max
        max = int(maximalgroesse.get())
        maximalgroesseText = Label(fenster, text="Maximalgroesse: " + str(max))
        maximalgroesseText.place(x = 0, y = 60, width=200, height=30)

def button_ende():
    cap.release()
    cv2.destroyAllWindows()
    global LOOP_ACTIVE
    LOOP_ACTIVE = false
    fenster.quit

cap = cv2.VideoCapture(0)
blackwhite = 0
# Ein Fenster erstellen
fenster = Tk()
# Den Fenstertitle erstellen
fenster.title("Benutzeroberfläche")
fenster.geometry("300x600")

SchwarzWeiss = Entry(fenster, bd=5, width=40)
SchwarzweissText = Label(fenster, text="SchwarzWeissfilter: "+ str(thresh))
mindestgroesse = Entry(fenster, bd=5, width=40)
maximalgroesse = Entry(fenster, bd=5, width=40)
maximalgroesseText = Label(fenster, text="Maximalgroesse: "+ str(max))

change_button = Button(fenster, text="Ändern", command=button_action)
exit_button = Button(fenster, text="Beenden", command=button_ende)
Anzahl = Label(fenster, text="Anzahl erkannter Vierecke "+ str(Anzahl))


mindestgroesseText = Label(fenster, text="Mindestgroesse: " + str(min))
SchwarzWeiss.place(x = 200, y = 0, width=100, height=30)
SchwarzweissText.place(x = 0, y = 0, width=200, height=30)
mindestgroesse.place(x = 200, y = 30, width=100, height=30)
mindestgroesseText.place(x = 0, y = 30, width=200, height=30)
change_button.place(x = 0, y = 500, width=300, height=50)
exit_button.place(x = 0, y = 550, width=300, height=50)
Anzahl.place(x = 0, y = 200, width=300, height=30)
maximalgroesse.place(x = 200, y = 60, width=100, height=30)
maximalgroesseText.place(x = 0, y = 60, width=200, height=30)

LOOP_ACTIVE = True
while LOOP_ACTIVE:





    ret, frame = cap.read()

    font = cv2.FONT_HERSHEY_COMPLEX

    img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    _, bw = cv2.threshold(img, thresh, 255, cv2.THRESH_BINARY)
    #    _, threshold = cv2.threshold(img, 240, 255, cv2.THRESH_BINARY)
    threshold = cv2.adaptiveThreshold(bw, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    contours, _ = cv2.findContours(threshold, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    Anzahl = 0
    list = []
    #list [xkooordinate mittelpunkt, ykoordinate mittelpunkt, drehung]
    #drehung zwischen 0 und 45 0 waagerecht
    print('neu')
    for cnt in contours:
        approx = cv2.approxPolyDP(cnt, 0.01 * cv2.arcLength(cnt, True), True)
#elemente aussortieren
        if len(approx) == 4 and cv2.contourArea(cnt) >= min and cv2.contourArea(cnt) <= max:
            xmittelpunkt = (approx.ravel()[0] + approx.ravel()[2] + approx.ravel()[4] + approx.ravel()[6]) / 4
            ymittelpunkt = (approx.ravel()[1] + approx.ravel()[3] + approx.ravel()[5] + approx.ravel()[7]) / 4
            dabei = False
#            checke ob das Viereck schon erkannt wurde
            for elm in list:
                if (xmittelpunkt-elm[0]<=1 or xmittelpunkt-elm[0]>=1 or ymittelpunkt-elm[1]<=1 or ymittelpunkt-elm[1]>=1):
                    dabei = True
            if dabei == False:
                Anzahl = Anzahl + 1

                drehung = np.arctan((approx.ravel()[3] - approx.ravel()[1]) / (approx.ravel()[2] - approx.ravel()[0]))
                drehung = drehung/np.pi*180
                cv2.drawContours(frame, [approx], 0, (0), 5)
                list.append([xmittelpunkt, ymittelpunkt, drehung])
                x = approx.ravel()[0]
                y = approx.ravel()[1]
                if y >=479:
                    y = 479
                if x >= 479:
                    x = 479
                color = frame[x, y]
                cv2.putText(frame, "B:"+str(color[0])+" G:"+str(color[1])+" R:"+str(color[2]), (x, y), font, 1, (0))
                print(approx.ravel())
                print(list)
    Anzahl = Label(fenster, text="Anzahl erkannter Vierecke " + str(Anzahl))
    Anzahl.place(x=0, y=200, width=300, height=30)
    cv2.imshow("shapes", frame)
    cv2.imshow("Threshold", threshold)
    fenster.update()


