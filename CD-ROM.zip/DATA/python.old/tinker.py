from modules.WebServer import *

server = WebServer()
server.startWebServer()