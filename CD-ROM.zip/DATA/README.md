# parcelcopter
Adding a parcel pickup functionality for an existing Quadrocopter.

#Remote Host Sync:
To Sync to a remote host, type
´bash RemoteHostSync.sh´
